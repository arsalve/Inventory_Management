/**
 * Show the loading modal.
 */
function showLoading() {
    $('#loadingModal').modal('show');
}

/**
 * Hide the loading modal.
 */
function hideLoading() {
    $('#loadingModal').modal('hide');
}

/**
 * Handle the form submission for creating an item.
 * @param {Event} e - The form submission event.
 */
document.getElementById('createItemForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    showLoading();
    const name = document.getElementById('name').value;
    const quantity = parseFloat(document.getElementById('quantity').value);
    const price = parseFloat(document.getElementById('price').value);
    const receivePrice = parseFloat(document.getElementById('receivePrice').value);
    const sellPrice = parseFloat(document.getElementById('sellPrice').value);
    const expiryDate = document.getElementById('expiryDate').value;
    const itemType = document.getElementById('itemType').value;

    const response = await fetch('/api/inventory/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, quantity, price, receivePrice, sellPrice, expiryDate, itemType })
    });

    hideLoading();
    if (response.ok) {
        alert('Item created successfully');
        $('#createItemModal').modal('hide');
        fetchItems();
    } else {
        alert('Failed to create item');
    }
});

/**
 * Handle the form submission for using an item.
 * @param {Event} e - The form submission event.
 */
document.getElementById('useItemForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    showLoading();
    const itemId = document.getElementById('useItemId').value;
    const quantityUsed = parseFloat(document.getElementById('quantityUsed').value);
    const usedBy = document.getElementById('usedBy').value;
    const reason = document.getElementById('reason').value;

    const response = await fetch(`/api/inventory/use/${itemId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ quantityUsed, usedBy, reason })
    });

    hideLoading();
    if (response.ok) {
        alert('Item used successfully');
        $('#useItemModal').modal('hide');
        fetchItems();
    } else {
        alert('Failed to use item');
    }
});

/**
 * Handle the form submission for removing an item.
 * @param {Event} e - The form submission event.
 */
document.getElementById('removeItemForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    showLoading();
    const removeItemId = document.getElementById('removeItemId').value;
    const quantityRemoved = parseFloat(document.getElementById('quantityRemoved').value);

    const response = await fetch(`/api/inventory/remove/${removeItemId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ quantityRemoved })
    });

    hideLoading();
    if (response.ok) {
        alert('Item removed successfully');
        $('#removeItemModal').modal('hide');
        fetchItems();
    } else {
        alert('Failed to remove item');
    }
});

/**
 * Fetch all inventory items and populate the table.
 */
async function fetchItems() {
    showLoading();
    const response = await fetch('/api/inventory');
    const items = await response.json();
    const tableBody = document.getElementById('inventoryTable').querySelector('tbody');
    tableBody.innerHTML = '';

    items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.name}</td>
            <td>${item.quantity}</td>
            <td>${item.price}</td>
            <td>${item.receivePrice}</td>
            <td>${item.sellPrice}</td>
            <td>${new Date(item.expiryDate).toLocaleDateString()}</td>
            <td>${item.itemType}</td>
            <td>
                <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#useItemModal" onclick="setUseItemId('${item._id}')">Use</button>
                <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#removeItemModal" onclick="setRemoveItemId('${item._id}')">Remove</button>
            </td>
        `;
        tableBody.appendChild(row);
    });

    hideLoading();
}

/**
 * Set the item ID for the use item modal.
 * @param {string} id - The item ID.
 */
function setUseItemId(id) {
    document.getElementById('useItemId').value = id;
}

/**
 * Set the item ID for the remove item modal.
 * @param {string} id - The item ID.
 */
function setRemoveItemId(id) {
    document.getElementById('removeItemId').value = id;
}

// Fetch items when the page loads
fetchItems();