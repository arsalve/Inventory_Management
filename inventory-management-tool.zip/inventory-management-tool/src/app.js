const express = require('express');
const mongoose = require('mongoose');
const inventoryRoutes = require('./routes/inventoryRoutes');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/**
 * Connect to MongoDB using the connection string from the .env file.
 */
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err));

/**
 * Use the inventory routes for any requests to /api/inventory.
 */
app.use('/api/inventory', inventoryRoutes);

/**
 * Serve static files from the "views" directory.
 */
app.use(express.static(path.join(__dirname, 'views')));

/**
 * Serve dashboard.html as the landing page.
 */
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});

/**
 * Start the server on the specified port.
 */
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});