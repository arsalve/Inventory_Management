# Inventory Management Tool Setup Guide

This guide will help you set up and use the Inventory Management Tool on your computer.

## Prerequisites

Before you start, make sure you have the following installed on your computer:
1. Node.js (v14 or higher)
2. npm (v6 or higher)
3. A MongoDB Atlas account

## Step-by-Step Instructions

### 1. Clone the Repository

1. Open your web browser and go to the GitHub repository page.
2. Click on the "Code" button and copy the repository URL.
3. Open a terminal or command prompt on your computer.
4. Type the following command and press Enter:
   ```sh
   git clone <repository-url>
   ```

### 2. Navigate to the Project Directory

1. In the terminal or command prompt, type the following command and press Enter:
   ```sh
   cd inventory-management-tool
   ```

### 3. Install the Dependencies

1. In the terminal or command prompt, type the following command and press Enter:
   ```sh
   npm install
   ```

### 4. Create a `.env` File

1. In the root directory of the project, create a new file named `.env`.
2. Open the `.env` file in a text editor and add the following lines:
   ```properties
   MONGO_URI=mongodb://localhost:27017/inventory_management
   PORT=3000
   SECRET_KEY=your_secret_key_here
   ```

### 5. Set Up MongoDB Atlas

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and sign up for a free account.
2. Create a new project.
3. Create a new cluster.
4. In the cluster, click on "Connect" and follow the instructions to whitelist your IP address and create a database user.
5. Choose "Connect your application" and copy the connection string. It will look something like this:
   ```
   mongodb+srv://<username>:<password>@cluster0.mongodb.net/inventory_management?retryWrites=true&w=majority
   ```
6. Replace `<username>` and `<password>` with the database user credentials you created.

### 6. Initialize the Application

1. In the terminal or command prompt, type the following command and press Enter:
   ```sh
   npm run init
   ```

### 7. Access the Inventory Management Tool

1. Open your web browser and navigate to `http://localhost:3000` to access the inventory management tool.

## Features

- Add new inventory items
- Retrieve a list of all inventory items
- Update existing inventory items
- Delete inventory items
- User-friendly HTML interface

## Project Structure

```
inventory-management-tool
├── src
│   ├── controllers
│   │   ├── inventoryController.js
│   ├── models
│   │   ├── inventoryModel.js
│   ├── routes
│   │   ├── inventoryRoutes.js
│   ├── views
│   │   ├── index.html
│   │   ├── dashboard.html
│   ├── app.js
├── package.json
├── .env
├── .gitignore
├── init.js
└── README.md
```

## API Endpoints

- `POST /api/inventory/create` - Add a new inventory item
- `GET /api/inventory` - Retrieve all inventory items
- `PUT /api/inventory/use/:id` - Use an inventory item by ID
- `DELETE /api/inventory/remove/:id` - Delete an inventory item by ID

## Resources

- [Node.js](https://nodejs.org/en/docs/) - JavaScript runtime built on Chrome's V8 JavaScript engine.
- [Express](https://expressjs.com/) - Fast, unopinionated, minimalist web framework for Node.js.
- [MongoDB](https://www.mongodb.com/) - NoSQL database for modern applications.
- [Mongoose](https://mongoosejs.com/) - Elegant MongoDB object modeling for Node.js.
- [dotenv](https://www.npmjs.com/package/dotenv) - Module that loads environment variables from a `.env` file into `process.env`.
- [Bootstrap](https://getbootstrap.com/) - The most popular HTML, CSS, and JS library in the world.

## Contributing

Feel free to submit issues or pull requests for improvements or bug fixes.

## License

This project is licensed under the MIT License.